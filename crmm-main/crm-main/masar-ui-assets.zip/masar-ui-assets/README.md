# Masar UI assets

## icons/ (44 SVG, 24px grid)
Stroke 1.75, round caps, `currentColor` (color them with CSS `color`).
- Navigation: dashboard, leads, tasks, whatsapp-queue, reports, team, settings, billing, integrations, notifications, company, menu, search, filter, language, user, logout
- Actions: add, new-lead, import, export, call, send-message, calendar, clock, assign, escalate, check, close, more, edit, trash, copy, link, chevron-down, arrow-end
- Status: success, warning, error, info, overdue
- Lead stages: stage-visit, stage-deal, stage-lost

RTL: mirror `arrow-end` and `logout` with `[dir="rtl"] .icon-flip { transform: scaleX(-1); }`. Do not mirror the rest.

## illustrations/ (240x180 SVG)
empty-leads, empty-tasks, empty-queue, empty-search, onboarding-import, onboarding-team, error-page. Contain no text, so they work in both languages.

## brand/
masar-logo.svg, masar-logo-dark.svg, masar-icon.svg, favicon.svg, favicon-32.png, apple-touch-icon.png (180), icon-192.png, icon-512.png, og-image.svg/png (1200x630).

## Colors
ink #0B3B3C, amber #F4B63F, paper #F7F5F0, muted #4C7C7A, tint #E3ECEB, tint-2 #CFE0DE

## HTML head
<link rel="icon" href="/brand/favicon.svg" type="image/svg+xml">
<link rel="apple-touch-icon" href="/brand/apple-touch-icon.png">
<meta property="og:image" content="/brand/og-image.png">
